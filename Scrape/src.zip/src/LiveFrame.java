
public class LiveFrame extends mainFrame {

	private static final long serialVersionUID = 1L;

	LiveFrame() throws Exception {

	}
}
