public class IntelieLogin {
	final String username = "samuel.parker@propetroservices.com";
	final String password = "Ranchbronc.311";
	final String clientId = "18d14569-c3bd-439b-9a66-3a2aee01d14f";

	IntelieLogin() {

	}

	public String rememberMeCookie() {

		return "";
	}
}
